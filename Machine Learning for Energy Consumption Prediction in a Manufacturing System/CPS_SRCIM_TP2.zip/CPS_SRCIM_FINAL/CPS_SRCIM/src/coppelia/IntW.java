package coppelia;

public class IntW
{
    int w;

    public IntW(int i)
    {
        w = i;
    }

    public void setValue(int i)
    {
        w = i;
    }

    public int getValue()
    {
        return w;
    }
}
