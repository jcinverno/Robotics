package coppelia;

public class StringW
{
    String w;

    public StringW(String s)
    {
        w = s;
    }

    public void setValue(String s)
    {
        w = s;
    }

    public String getValue()
    {
        return w;
    }
}