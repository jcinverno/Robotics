package Product;

import jade.core.behaviours.OneShotBehaviour;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAException;

import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.proto.ContractNetInitiator;
import jade.proto.AchieveREInitiator;

import java.util.Random;
import java.util.Vector;

import jade.core.Agent;

import java.util.ArrayList;

import Utilities.DFInteraction;


import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

/**
 * @author Ricardo Silva Peres <ricardo.peres@uninova.pt>
 */
public class ProductAgent extends Agent {

    ArrayList<String> executionPlan = new ArrayList<>();

    ArrayList<String> stationsAvailable = new ArrayList<>();
    DFAgentDescription[] dfAgentDescriptions;
    DFAgentDescription[] dfAgentSkills;
    boolean resource_negotiation_done;
    String id, next_location, current_location;
    AID agv, transport, my_resource, my_skill;
    int execution_step, choseni;

    double minprediction;
    static String station, skill, velocity, prediction, skillAndVelocity ;

    @Override
    protected void setup() {
        Object[] args = this.getArguments();
        this.id = (String) args[0];
        this.executionPlan = this.getExecutionList((String) args[1]);
        System.out.println("Product launched: " + this.id + " Requires: " + executionPlan);

        this.current_location = "Source";
        this.resource_negotiation_done = false;
        this.execution_step = 0;
        this.my_resource = null;
        this.my_skill = null;
        this.minprediction = 100000000.0;
        this.choseni = 0;

        Random random = new Random();
        int randomNumber = random.nextInt(4); //NUMBERS BETWEEN 0 AND 3

        if (randomNumber==0){velocity= "40";}
        else if (randomNumber==1){velocity= "50";}
        else if (randomNumber==2){velocity= "60";}
        else {velocity= "75";}

        this.addBehaviour(new find_resource(this));

    }

    @Override
    protected void takeDown() {
        super.takeDown();
    }

    private ArrayList<String> getExecutionList(String productType) {
        switch (productType) {
            case "A":
                return Utilities.Constants.PROD_A;
            case "B":
                return Utilities.Constants.PROD_B;
            case "C":
                return Utilities.Constants.PROD_C;
        }
        return null;
    }

    /*****contract net*****/
    private class initiator extends ContractNetInitiator {
        public initiator(Agent a, ACLMessage msg) {
            super(a, msg);

        }

        @Override
        protected void handleInform(ACLMessage inform) {
            System.out.println(myAgent.getLocalName() + ": INFORM message received");
            ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
            next_location = inform.getContent();

            try { //request
                System.out.println("Looking for Transport...");
                DFAgentDescription[] dfAgentDescriptions = DFInteraction.SearchInDFByName("sk_move", myAgent);

                transport = dfAgentDescriptions[0].getName();
                //System.out.println(transport);
                msg.addReceiver(transport);
            }
            catch (FIPAException e){
                throw new RuntimeException(e);
            }

            String location = current_location + "#" + next_location + "&" + id;
            msg.setContent(location);

            System.out.println("Sending locations to transport");
            myAgent.addBehaviour(new initiatorFIPA_TA(myAgent, msg));

        }

        @Override
        protected void handleAllResponses(Vector responses, Vector acceptances) {

            System.out.println(myAgent.getLocalName() + ": ALL PROPOSALS received");

            for (int i = 0; i < responses.size(); i++) {

                ACLMessage auxMsg = (ACLMessage) responses.get(i);
                String prediction = auxMsg.getContent();

                    if (prediction != null) {
                        System.out.println(prediction);
                        double predictedValue = Double.parseDouble(prediction.replace("{\"prediction\":", "").replace("}", ""));

                        if (predictedValue < minprediction) {
                            minprediction = predictedValue;
                            choseni = i;

                        }
                    }
                }

            //System.out.println("Beste Prediction: " + minprediction);
            minprediction = 1000000.0; // reinicializar valor
            ACLMessage Msg = (ACLMessage) responses.get(choseni);
            ACLMessage reply = Msg.createReply();
            System.out.println("Accepting proposal " + reply + " from responder " + Msg.getSender());
            my_resource = Msg.getSender();
            reply.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
            acceptances.add(reply);

            for (int i = 0; i < responses.size(); i++) {
                if (choseni != i) {
                    ACLMessage auxMsg2 = (ACLMessage) responses.get(i);
                    ACLMessage reply2 = auxMsg2.createReply();
                    System.out.println("(CFP) REFUSE received from: " + auxMsg2.getSender().getLocalName());
                    reply2.setPerformative(ACLMessage.REJECT_PROPOSAL);
                    acceptances.add(reply2);
                }
            }

        }


    }

    private class find_resource extends OneShotBehaviour {
        public find_resource(Agent a) {
            super(a);
        }

        public void action() {
            ACLMessage msg = new ACLMessage(ACLMessage.CFP); // create a new CFP message
            try {
                System.out.println("Looking for resource: ");
                dfAgentDescriptions = DFInteraction.SearchInDFByName(executionPlan.get(execution_step), myAgent);

                for (int i = 0; i < dfAgentDescriptions.length; i++) {
                    msg.addReceiver(dfAgentDescriptions[i].getName()); // add the receivers to the message
                    System.out.println(msg);

                }
                String skillAndVelocity = executionPlan.get(execution_step) + "&" + velocity;
                msg.setContent(skillAndVelocity); // CFP SKILL
                myAgent.addBehaviour(new initiator(myAgent, msg)); // create a new "initiator" behaviour to send the message


            } catch (FIPAException e) {
                throw new RuntimeException(e);
            }
        }
    }


    /*************Fipa request ********/

    private class initiatorFIPA_TA extends AchieveREInitiator {
        public initiatorFIPA_TA(Agent a, ACLMessage msg) {
            super(a, msg);
        }

        @Override
        protected void handleAgree(ACLMessage agree) {

            System.out.println(myAgent.getLocalName() + ": AGREE message received " + agree.getSender().getLocalName());
        }

        @Override
        protected void handleInform(ACLMessage inform) {
            System.out.println(myAgent.getLocalName() + ": INFORM message received " + inform.getSender().getLocalName());

            ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);

            msg.addReceiver(my_resource);
            msg.setContent(executionPlan.get(execution_step));
            myAgent.addBehaviour(new initiatorFIPA_RA(myAgent, msg));

            current_location = next_location;

        }
    }


  private class initiatorFIPA_RA extends AchieveREInitiator {
        public initiatorFIPA_RA(Agent a, ACLMessage msg) {
           super(a, msg);
        }
       @Override
        protected void handleAgree(ACLMessage agree) {
           System.out.println(myAgent.getLocalName() + ": AGREE to execute skill");
       }

        @Override
        protected void handleInform(ACLMessage inform) {
           System.out.println(myAgent.getLocalName() + ": INFORM skill is finished");

            ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
            try{

                if(executionPlan.size() > execution_step){
                    dfAgentSkills = DFInteraction.SearchInDFByName(executionPlan.get(execution_step), myAgent);

                    for (int i = 0; i < dfAgentDescriptions.length; i++) {
                        msg.addReceiver(dfAgentDescriptions[i].getName()); // add the receivers to the message
                        System.out.println(msg);

                    }
                    msg.setContent(executionPlan.get(execution_step));

                    execution_step++;
                    myAgent.addBehaviour(new find_resource(myAgent));
                }
                else{
                    System.out.println("Done!");
                }
            } catch (FIPAException e){
                throw new RuntimeException(e);

           }

       }
  }

}
